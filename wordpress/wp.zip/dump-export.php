<?php
ini_set('max_execution_time', 300);
error_reporting(E_ALL);

require_once('wp-config.php');
global $table_prefix;
$host = escapeshellarg(DB_HOST);
$user = escapeshellarg(DB_USER);
$pass = escapeshellarg(DB_PASSWORD);
$db_name = escapeshellarg(DB_NAME);
$filename = escapeshellarg('dump.sql');
$filename_zip = escapeshellarg('dump.sql.zip');

$dump_statement = "mysqldump -h $host -u $user -p{$pass} $db_name \$(mysql -h $host -u $user -p{$pass} -D $db_name -Bse \"show tables like '{$table_prefix}%'\") > $filename 2>&1";
$zip_statement = "zip -u $filename_zip $filename";
$rm_statement = "rm $filename";

if (function_exists('system')) {
    system($dump_statement); // 2>&1
    system($zip_statement);
    system($rm_statement);
} else {
    echo '<code>system()</code> is not supported. Copy-paste the following via SSH:';
    echo "<pre>$dump_statement\n$zip_statement\n$rm_statement\n\n</pre>";
}
?>